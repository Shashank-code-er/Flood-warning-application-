# Flood Early Warning — Advanced Starter

This is the advanced starter repository for the Flood Early Warning mobile + backend system.

Contents:
- mobile/ (Expo React Native skeleton)
- backend/ (Node.js + Express skeleton)
- docker-compose.yml and infra notes
