Infra notes:
- Use Docker Compose for local testing
- For production use Kubernetes and managed DBs
